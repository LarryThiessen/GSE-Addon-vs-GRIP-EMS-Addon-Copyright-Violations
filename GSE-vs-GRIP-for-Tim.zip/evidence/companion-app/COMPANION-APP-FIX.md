# GSE Companion — the one thing to fix (for Timothy Luke)

**Purpose:** the companion-app analysis found the "spies on you / deletes your data" claims to be refuted or misframed — **except one item that is a fair, legitimate criticism.** Fixing it removes the last shred of truth the critics can point to and turns their strongest point into a shipped improvement. This is a **developer to-do for you**, not a legal document.

> Analyzed against the shipped **GSE Companion 0.4.22** build (`app.asar` → `out/main/index.js`, 137,312 bytes; SHA-256 `27716e71…4cd6e1`, which matches the discloser's own `hashes.txt`). Line numbers below are into that built `index.js` — map them to your source. **Confirm each against your real source before shipping.** See `COMPANION-FORENSIC-FINDINGS.md` §3 for the full context.

---

## TL;DR

There is **one unsigned code path** that can gather files from the WoW folder and upload them, and it is **not** protected by the same ed25519 signature gate your destructive/directive path already uses. **No evidence it was ever misused** — but it *should* be signed, opt-in, and scope-limited. Do that and the "it can read/upload your files without asking" argument is gone.

---

## The issue — the unsigned diagnostic upload

- An SSE message `companion:request` (`index.js` ~1704) triggers `zo()` (~1455), which:
  - gathers files **by kind** — including **BugGrabber/BugSack** error logs via the `Ao` regex `/^!?Bug(Grabber|Sack)\.lua$/i` (~911 / ~997), **and**
  - reads **server-specified paths** under `Interface\AddOns` and `WTF`,
  - then **POSTs their contents** to `/diagnostic/upload` (~1479).
- **This path is not ed25519-signed and not `enforce`-gated.** Compare: your *directive* engine (`qo()` verify ~1055 → `Jo()`/`Po()` run ~1514) only runs a plan if it is **signed, unexpired, persona-matched, and WoW is closed**. The diagnostic upload has none of those guards.
- Practical reach: it can read the server-named files under AddOns/WTF and the BugGrabber/BugSack logs, and send them up — on an unsigned server request.

**Why this is the fair point:** everything else the critics raised was refuted (the delete never armed — `enforce:false` on all three of their own captures — and is removed) or misframed (the "paywall," the "bans"). This one is real: a path that *can* pull a user's files without a signature or an explicit opt-in. Own it and fix it.

---

## The fix — three changes

1. **Sign it.** Require the same `v2:` ed25519 signature on every `companion:request` / gather / upload that the directive path already enforces via `qo()`. An unsigned request should be rejected before `zo()` runs. (One gate, reused — you already have the verifier.)
2. **Make it opt-in.** Tie any file gather/upload to a **user-initiated bug report** (you already have `As()` / `report:submit` ~2949/2982, which honors `includeModList`). No silent/background collection: the user clicks "send report," sees what's attached, and confirms.
3. **Scope it down.** Restrict reads to **GSE's own files** (and only what a bug report needs), not arbitrary server-specified paths under AddOns/WTF. Publish, in plain language, exactly what a report attaches.

---

## How to verify after the change

1. Rebuild; extract `app.asar` → `out/main/index.js`.
2. Confirm the `companion:request` → `zo()` → `/diagnostic/upload` path now **rejects an unsigned request** (same failure as an unsigned directive plan).
3. Confirm no gather/upload fires without a user-initiated report + confirmation.
4. Confirm reads are limited to GSE's own files.
5. Bump the version and note the hardening in the changelog — then the public answer is "it's signed, opt-in, and scoped; here's the build hash," not a denial.

---

*Not legal advice. Prepared from a read of the shipped binary; you are the author and hold the real source — verify before shipping. Pairs with `RESPONSE-brief-for-Tim.html` (§4, the same point) and `COMPANION-FORENSIC-FINDINGS.md` (§3, full detail).*
